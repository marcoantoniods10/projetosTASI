//importação das libs:
const express = require ('express');
const router = require('./routes/index');

//configuração 

const app = express();
app.use ('/', router);

// Exportação:
module.exports = app;
