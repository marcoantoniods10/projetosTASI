// Importação do express:
const express = require ('express')
//Importação de Variaveis de Ambiente:
require('dotenv').config({path: 'variables.env'});

// Rotas
const router = express.Router();
router.get('/', (req, res) =>{
    res.send("Mensagem enviada pelo index.js em /routes")

});

//Rota 1 "/rota1":
router.get('/rota1', (req, res) =>{
    res.send("Nome: " + req.query.nome + " Idade: " + req.query.idade + " Anos....")

});

//Rota 2 "/rota2":
router.get('/rota2', (req, res) =>{
    res.send("Nome: " + process.env.NOMEVAR + " Idade: " + process.env.IDADEVAR + " Anos....")

});

//Rota 2 "/rota2":
router.get('/rota3', (req, res) =>{
    let num1 = parseFloat(req.query.num1);
    let num2 = parseFloat(req.query.num2);
    let soma = num1 + num2;
    res.send("SOMA = " + num1 + " + " + num2 + " = " + soma )

});

//Exportar:

module.exports = router;