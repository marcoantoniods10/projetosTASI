// Importação:
const app = require ('./app');

//Importação de Variaveis de Ambiente:
require('dotenv').config({path: 'variables.env'});

//app.set('PORT', 1234);

app.set('port', process.env.PORT || 5555)
const server = app.listen(app.get('port'), () => {
    console.log ("Servidor rodando em: " + server.address().port);
});